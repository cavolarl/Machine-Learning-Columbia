References:
The Perceptrons are from the homework assignment and the lecture slides. A lot of code from the previous assignment for loading data
and calculating accuracy has been reused.

Instructions:
1. P0 corresponds to Perceptron_V0 and so forth for P1, P2
2. KP being the Kernel Perceptron
3. To run, just have numpy and scipy installed and run them like you would run any python code
4. The hyperparameters and parameters are set in the code itself. There are comments indicating where they are.