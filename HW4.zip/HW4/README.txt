The extended Lloyds is based on the lectures but the k-means++ initialization is inspired by: https://www.geeksforgeeks.org/ml-k-means-algorithm/

# Running the codes is simple, chain, concentric and sparse are just to run. newLloyd contains the improved algorithm that uses datasets.py
for the data sets. Just change the name of the dataset near the bottom to run the different datasets.